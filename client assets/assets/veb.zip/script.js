const Ime=document.getElementById("ime")
const Email=document.getElementById("mail")
const Pitanje=document.getElementById("pitanje")
const salji = document.getElementById("submit");
const resetuj = document.getElementById("reset");
const greska = document.getElementById("greska");


salji.addEventListener("click", function(ev){

    const vrednostIme=ime.value.trim()
    if(vrednostIme==" "){
        greska.textContent="Unesite ime";
        ev.preventDefault()
        inputIme.focus()
        return false;
    }

})